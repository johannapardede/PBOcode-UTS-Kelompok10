package com.klinik;

/*
 * Abstract (parent) class Produk
 * Diturunkan oleh Skincare dan Makeup
 */
public abstract class Produk {

    // Atribut
    private String namaProduk;
    private double hargaProduk;
    private String kategori;
    private int qty;

    // Constructor
    public Produk(String namaProduk, double hargaProduk, String kategori, int qty) {
        this.namaProduk = namaProduk;
        this.hargaProduk = hargaProduk;
        this.kategori = kategori;
        this.qty = qty;
    }

    // Setter dan getter
    public void setNamaProduk(String namaProduk) {
        this.namaProduk = namaProduk;
    }

    public String getNamaProduk() {
        return namaProduk;
    }

    public void setHargaProduk(double hargaProduk) {
        this.hargaProduk = hargaProduk;
    }

    public double getHargaProduk() {
        return hargaProduk;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getKategori() {
        return kategori;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public int getQty() {
        return qty;
    }

    // Method biasa (dipakai bersama oleh semua subclass)
    public double hitungSubtotal() {
        return hargaProduk * qty;
    }

    // Abstract method (wajib diimplementasikan subclass)
    public abstract String getJenis();

    public abstract Produk salin(int qtyBaru);
}