package com.klinik;

/*
 * Interface Struk
 * Berisi data tetap (konstanta) dan method pencetak struk
 */
public interface Struk {

    // Data bagian atas struk (otomatis public static final)
    String HEADER_KLINIK = "NATASHA MOI";
    String NAMA_PT = "PT. Pesona Natasha Gemilang";
    String ALAMAT_1 = "Jl. Urip Sumuharjo No.65 Klitren, Yogyakarta";
    String ALAMAT_2 = "Kota Yogyakarta D.I Yogyakarta 55222";
    String TELP_KLINIK = "Call Center : 150500";

    // Data bagian bawah struk
    String FOOTER_1 = "Cocokkan kembali transaksi pembelian anda";
    String FOOTER_2 = "dengan struk/nota transaksi yang telah anda terima";
    String FOOTER_3 = "Terima kasih atas kunjungan anda";

    // Method untuk mencetak struk (otomatis public abstract)
    void cetakBarisStruk();
}